from pathlib import Path
root=Path('/workspace/scratch/1f6e2f637e9a/jobs-resume/reputation-candidate')
s=(root/'test/v2/ReputationTerminalIntegrationV3.test.ts').read_text().split('async function validateRound(')[0]
s=s.replace("'../../scripts/deploy/implementations.cjs'",repr(str(root/'scripts/deploy/implementations.cjs'))).replace("'../../scripts/constants'",repr(str(root/'scripts/constants')))
s=s.replace('async function deploySystem() {','async function deploySystem(n: number) {')
s=s.replace('const [owner, employer, agent, validator, buyer, moderator, v2, v3] =\n    await ethers.getSigners();', '''const [owner, employer, agent, buyer, moderator] = await ethers.getSigners();
  const validators = Array.from({length:n}, (_,i) => new ethers.Wallet(ethers.id(`EPHEMERAL LOCAL GAS BENCHMARK ${n} ${i}`), ethers.provider));
  const validator = validators[0];
  for (const v of validators) await ethers.provider.send('hardhat_setBalance', [v.address, ethers.toBeHex(ethers.parseEther('100'))]);''')
s=s.replace('[validator, v2, v3]', 'validators')
s=s.replace('    30,\n    30,\n    3,\n    3,', '    7200,\n    7200,\n    3,\n    n,')
s=s.replace('  const validators = validators;', '''  await validation.setMaxValidatorsPerJob(Math.max(n,100));
  await validation.setValidatorPoolSampleSize(n);
  await validation.setValidatorsPerJob(n);
  await validation.setRevealQuorum(67,3);
  await validation.setEarlyFinalizeDelay(0);''')
s=s.replace('  await identity.addAdditionalValidator(v2.address);\n  await identity.addAdditionalValidator(v3.address);', '  for (const v of validators) await identity.addAdditionalValidator(v.address);')
s += '\nexport { deploySystem, leaf, Role };\n'
Path('/workspace/scratch/1f6e2f637e9a/closure-gas/fixture.ts').write_text(s)
