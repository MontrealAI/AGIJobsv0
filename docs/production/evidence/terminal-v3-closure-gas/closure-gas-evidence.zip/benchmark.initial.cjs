'use strict';
const fs=require('fs'), path=require('path'),crypto=require('crypto');
const hre=require('hardhat');
const {ethers,artifacts}=hre;
const {time}=require('@nomicfoundation/hardhat-network-helpers');
const {deploySystem,Role}=require('./fixture.cjs');
const root='/workspace/scratch/1f6e2f637e9a/jobs-resume/reputation-candidate';
const out=__dirname;
const profile=process.env.BENCH_PROFILE||'native-osaka';
const sizes=(process.env.BENCH_SIZES||'100,256').split(',').map(Number);
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const stringify=x=>JSON.stringify(x,(_,v)=>typeof v==='bigint'?v.toString():v,2);
const report={profile,startedAt:new Date().toISOString(),scope:'Functional full ValidationModule closure gas benchmark; not a security review or deployment approval',network:{name:hre.network.name,hardfork:hre.network.config.hardfork,configuredBlockGasLimit:hre.network.config.blockGasLimit,configuredDefaultTxGas:hre.network.config.gas,chainId:hre.network.config.chainId},tooling:{node:process.version,hardhat:require('hardhat/package.json').version,ethers:ethers.version},cases:[],setup:[],failures:[]};
if(hre.network.name!=='hardhat'||hre.network.config.forking)throw new Error('Only ephemeral unforked Hardhat permitted');
const save=()=>fs.writeFileSync(path.join(out,profile+'.json'),stringify(report)+'\n');
async function txRecord(tx,label){let r=await tx.wait(),b=await ethers.provider.getBlock(r.blockNumber);return {label,hash:tx.hash,gasUsed:r.gasUsed,gasLimit:tx.gasLimit,calldataBytes:(tx.data.length-2)/2,blockGasLimit:b.gasLimit,blockNumber:r.blockNumber,timestamp:b.timestamp,status:r.status,logCount:r.logs.length};}
async function inventory(env){let inv={};for(const name of ['validation','stake','reputation','registry','dispute','identity','nft','feePool','token','ens','wrapper']){let c=env[name],a=await c.getAddress(),code=await ethers.provider.getCode(a);inv[name]={address:a,runtimeBytes:(code.length-2)/2,runtimeKeccak256:ethers.keccak256(code)};if(['validation','stake','registry'].includes(name)){inv[name].implementations=[];for(const a of await c.implementationModules()){let code=await ethers.provider.getCode(a);inv[name].implementations.push({address:a,runtimeBytes:(code.length-2)/2,runtimeKeccak256:ethers.keccak256(code)});}}}return inv;}
async function prepare(n){
 let env=await deploySystem(n);let {identity,wrapper,agent,token,stake,stakeAmt,employer,registry,reputation,validation,validators}=env;
 let node=ethers.keccak256(ethers.solidityPacked(['bytes32','bytes32'],[await identity.agentRootNode(),ethers.id('agent')]));
 await wrapper.setOwner(BigInt(node),agent.address);
 await reputation.add(agent.address,19036);
 await token.connect(agent).approve(await stake.getAddress(),stakeAmt); await stake.connect(agent).depositStake(Role.Agent,stakeAmt);
 for(let i=0;i<validators.length;i++){const v=validators[i];await token.connect(v).approve(await stake.getAddress(),stakeAmt);await stake.connect(v).depositStake(Role.Validator,stakeAmt);await reputation.add(v.address,100);}
 let reward=ethers.parseUnits('100',18);await token.connect(employer).approve(await stake.getAddress(),reward);
 await registry.connect(employer).createJob(reward,BigInt((await time.latest())+86400),ethers.id('spec'),'ipfs://job');
 await registry.connect(agent).applyForJob(1,'agent',[]);await registry.connect(agent).submit(1,ethers.id('result'),'ipfs://result','agent',[]);await registry.connect(employer).submitBurnReceipt(1,ethers.id('burn'),0,0);
 await ethers.provider.send('evm_mine',[]);
 return env;
}
async function takeState(env,n){let {validation,reputation,registry,stake,employer,token}=env,r=await validation.rounds(1),selected=Array.from(await validation.validators(1));return {selectedValidators:selected,selectedCount:selected.length,selectedArrayAbiBytes:32+32*selected.length,round:{commitDeadline:r.commitDeadline,revealDeadline:r.revealDeadline,committeeSize:r.committeeSize,revealedCount:r.revealedCount,approvals:r.approvals,rejections:r.rejections},engine:await reputation.jobAccounting(await registry.getAddress(),1),employerTokenBalance:await token.balanceOf(employer.address),validator0:{stake:await stake.stakeOf(env.validators[0].address,Role.Validator),locked:await stake.lockedStakes(env.validators[0].address),reputation:await reputation.reputation(env.validators[0].address)}};}
async function runCase(env,n,mode){
 let {validation,registry,employer,validators,reputation,stake,token}=env;
 let nonce=await validation.jobNonce(1),specHash=await registry.getSpecHash(1),burn=ethers.id('burn'),chainId=(await ethers.provider.getNetwork()).chainId,domain=await validation.DOMAIN_SEPARATOR(),coder=ethers.AbiCoder.defaultAbiCoder();
 let revealCount=mode==='timeout-none'||mode==='force-timeout-none'?0:mode==='timeout-one-missing'?n-1:mode==='timeout-minority'?Math.floor(n/3):n;
 let approvals=validators.map((_,i)=>mode==='early-mixed'?i<Math.ceil(n*.7):true);
 let c={n,mode,closureMethod:mode.startsWith('force-')?'forceFinalize':'finalize',configuration:{commitWindow:await validation.commitWindow(),revealWindow:await validation.revealWindow(),forceFinalizeGrace:await validation.forceFinalizeGrace(),maxValidatorsPerJob:await validation.maxValidatorsPerJob(),sampleSize:await validation.validatorPoolSampleSize(),validatorsPerJob:await validation.validatorsPerJob(),approvalThreshold:await validation.approvalThreshold(),requiredApprovals:await validation.requiredValidatorApprovals(),revealQuorumPct:await validation.revealQuorumPct(),minRevealValidators:await validation.minRevealValidators(),incorrectVoteSlashPct:await validation.validatorSlashingPercentage(),nonRevealPenaltyBps:await validation.nonRevealPenaltyBps(),nonRevealBanBlocks:await validation.nonRevealBanBlocks(),stakePerValidator:env.stakeAmt,validatorReputation:100,jobReward:ethers.parseUnits('100',18),registryValidatorRewardPct:await registry.validatorRewardPct(),registryFeePct:await registry.feePct(),stakeBurnPct:await stake.burnPct()},commitTransactions:[],revealTransactions:[],timingChecks:[]};
 report.cases.push(c);save();
 let salts=validators.map(v=>ethers.id('salt:'+v.address));
 for(let i=0;i<n;i++){let outcome=ethers.keccak256(coder.encode(['uint256','bytes32','bool','bytes32'],[nonce,specHash,approvals[i],burn]));let commitment=ethers.keccak256(coder.encode(['uint256','bytes32','bytes32','address','uint256','bytes32'],[1,outcome,salts[i],validators[i].address,chainId,domain]));c.commitTransactions.push(await txRecord(await validation.connect(validators[i]).commitValidation(1,commitment,'validator',[]),'commit'));}
 let round=await validation.rounds(1);await time.increaseTo(round.commitDeadline+1n);
 for(let i=0;i<revealCount;i++)c.revealTransactions.push(await txRecord(await validation.connect(validators[i]).revealValidation(1,approvals[i],burn,salts[i],'validator',[]),'reveal'));
 c.preClose=await takeState(env,n);
 c.internalRecordRoundCalldataBytes=(reputation.interface.encodeFunctionData('recordRound',[await registry.getAddress(),1,await validation.entropyRound(1),c.preClose.selectedValidators,c.preClose.selectedValidators.map(v=>validators.findIndex(x=>x.address===v)<revealCount),c.preClose.selectedValidators.map(v=>{let i=validators.findIndex(x=>x.address===v);return i<revealCount&&approvals[i];}),true]).length-2)/2;
 c.registryResultCalldataBytes=(registry.interface.encodeFunctionData('onValidationResult',[1,true,c.preClose.selectedValidators]).length-2)/2;
 if(revealCount<n){
  // Exercise the contract at the exact promised deadline, without consuming a transaction.
  await time.increaseTo(round.revealDeadline);
  try{await validation.finalize.staticCall(1);c.timingChecks.push({at:'exact revealDeadline',unexpectedSuccess:true});}catch(e){c.timingChecks.push({at:'exact revealDeadline',reverted:true,error:e.shortMessage||e.message});}
  let ts=c.closureMethod==='forceFinalize'?round.revealDeadline+await validation.forceFinalizeGrace()+1n:round.revealDeadline+1n;
  await ethers.provider.send('evm_setNextBlockTimestamp',[Number(ts)]);
 }else if(BigInt(await time.latest())>=round.revealDeadline)throw new Error('Early case exceeded reveal deadline');
 let gasLimit=profile==='native-osaka'?16777216n:30000000n;
 try{
  c.estimatedGas=await validation[c.closureMethod].estimateGas(1);
  c.closure=await txRecord(await validation[c.closureMethod](1,{gasLimit}),'full ValidationModule closure');
  c.postClose=await takeState(env,n);
  let account=await reputation.jobAccounting(await registry.getAddress(),1);
  if(account.validatorCount!==BigInt(n)||!account.roundRecorded)throw new Error('Incomplete engine snapshot');
  for(let i=0;i<n;i++){let v=validators[i];if((await stake.lockedStakes(v.address))!==0n)throw new Error('Validator remains locked');let selectedIndex=c.preClose.selectedValidators.indexOf(v.address),fact=await reputation.validatorFact(await registry.getAddress(),1,selectedIndex);if(fact.validator!==v.address||fact.revealed!==(i<revealCount)||fact.vote!==(i<revealCount&&approvals[i]))throw new Error('Bad persisted validator facts '+i);}
  c.assertions={engineAllValidatorsRecorded:true,allValidatorLocksCleared:true,allPersistedValidatorFactsVerified:true,validationCommitteeCleared:c.postClose.selectedCount===0,closureBeforeDeadline:BigInt(c.closure.timestamp)<round.revealDeadline,closureStrictlyAfterDeadline:BigInt(c.closure.timestamp)>round.revealDeadline,agentTerminalSettlementPerformed:account.settled};
  console.log('RESULT',n,mode,'gasUsed='+c.closure.gasUsed,'estimate='+c.estimatedGas,'blockLimit='+c.closure.blockGasLimit);
 }catch(e){c.failure={message:e.shortMessage||e.message,data:e.data,transactionHash:e.transactionHash};report.failures.push({n,mode,...c.failure});console.log('FAIL',n,mode,c.failure.message);}
 save();
}
async function main(){
 let freezePath=path.join(root,'../reputation-round5-source-freeze.json'),freeze=JSON.parse(fs.readFileSync(freezePath));
 report.sourceFreeze={path:freezePath,manifestSha256:sha(fs.readFileSync(freezePath)),files:freeze.length,mismatches:freeze.filter(x=>sha(fs.readFileSync(path.join(root,x.path)))!==x.sha256)};
 if(report.sourceFreeze.mismatches.length)throw new Error('Source freeze mismatch');
 report.builds={};for(let fqn of ['contracts/v2/ValidationModule.sol:ValidationModule','contracts/v2/implementation/ValidationModuleVoting.sol:ValidationModuleVoting','contracts/v2/JobRegistry.sol:JobRegistry','contracts/v2/implementation/JobRegistrySettlement.sol:JobRegistrySettlement','contracts/v2/ReputationEngine.sol:ReputationEngine','contracts/v2/StakeManager.sol:StakeManager']){let a=await artifacts.readArtifact(fqn),p=path.join(root,'artifacts',a.sourceName,a.contractName+'.dbg.json'),d=JSON.parse(fs.readFileSync(p)),b=JSON.parse(fs.readFileSync(path.resolve(path.dirname(p),d.buildInfo)));report.builds[fqn]={buildId:b.id,solcVersion:b.solcVersion,solcLongVersion:b.solcLongVersion,settings:b.input.settings,artifactSha256:sha(fs.readFileSync(path.join(path.dirname(p),a.contractName+'.json'))),sourceSha256:sha(fs.readFileSync(path.join(root,a.sourceName)))};delete report.builds[fqn].settings.outputSelection;}
 save();
 for(let n of sizes){console.log('PREPARE',profile,n);await ethers.provider.send('hardhat_reset',[]);let setup={n};report.setup.push(setup);let env;
  try{env=await prepare(n);setup.inventory=await inventory(env);setup.selection=await txRecord(await env.validation.connect(env.employer).selectValidators(1,0,{gasLimit:profile==='native-osaka'?16777216n:60000000n}),'real committee selection');setup.selectedCount=(await env.validation.validators(1)).length;console.log('SELECTED',n,'gasUsed='+setup.selection.gasUsed);if(setup.selectedCount!==n)throw new Error('Wrong selected committee size');}
  catch(e){setup.failure={message:e.shortMessage||e.message,stack:e.stack,data:e.data,transactionHash:e.transactionHash};report.failures.push({n,stage:'setup',...setup.failure});console.log('SETUP FAIL',n,setup.failure.message);save();continue;}
  if(profile!=='native-osaka'){await ethers.provider.send('evm_setBlockGasLimit',['0x1c9c380']);await ethers.provider.send('evm_mine',[]);setup.closureBlockGasLimit=(await ethers.provider.getBlock('latest')).gasLimit;}
  let snap=await ethers.provider.send('evm_snapshot',[]);
  for(let mode of ['early-all-approve','early-mixed','timeout-one-missing','timeout-none','force-timeout-none']){await ethers.provider.send('evm_revert',[snap]);snap=await ethers.provider.send('evm_snapshot',[]);try{await runCase(env,n,mode);}catch(e){report.failures.push({n,mode,stage:'preparation-or-verification',message:e.stack||e.message});console.log('CASE FAIL',n,mode,e.message);save();}}
 }
 report.sourceFreeze.mismatchesAfter=freeze.filter(x=>sha(fs.readFileSync(path.join(root,x.path)))!==x.sha256);report.completedAt=new Date().toISOString();save();
}
main().catch(e=>{report.fatal=e.stack||e.message;save();console.error(e);process.exitCode=1;});
