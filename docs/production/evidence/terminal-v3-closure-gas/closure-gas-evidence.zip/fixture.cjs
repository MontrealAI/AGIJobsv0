"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
exports.deploySystem = deploySystem;
exports.leaf = leaf;
const implementations_cjs_1 = require("/workspace/scratch/1f6e2f637e9a/jobs-resume/reputation-candidate/scripts/deploy/implementations.cjs");
const chai_1 = require("chai");
const hardhat_1 = require("hardhat");
const constants_1 = require("/workspace/scratch/1f6e2f637e9a/jobs-resume/reputation-candidate/scripts/constants");
function leaf(addr, label) {
    return hardhat_1.ethers.keccak256(hardhat_1.ethers.AbiCoder.defaultAbiCoder().encode(['address', 'bytes32'], [addr, hardhat_1.ethers.id(label)]));
}
var Role;
(function (Role) {
    Role[Role["Agent"] = 0] = "Agent";
    Role[Role["Validator"] = 1] = "Validator";
    Role[Role["Platform"] = 2] = "Platform";
})(Role || (exports.Role = Role = {}));
async function deploySystem(n) {
    const [owner, employer, agent, buyer, moderator] = await hardhat_1.ethers.getSigners();
    const validators = Array.from({ length: n }, (_, i) => new hardhat_1.ethers.Wallet(hardhat_1.ethers.id(`EPHEMERAL LOCAL GAS BENCHMARK ${n} ${i}`), hardhat_1.ethers.provider));
    const validator = validators[0];
    for (const v of validators)
        await hardhat_1.ethers.provider.send('hardhat_setBalance', [v.address, hardhat_1.ethers.toBeHex(hardhat_1.ethers.parseEther('100'))]);
    const artifact = await hardhat_1.artifacts.readArtifact('contracts/test/AGIALPHAToken.sol:AGIALPHAToken');
    await hardhat_1.ethers.provider.send('hardhat_setCode', [
        constants_1.AGIALPHA,
        artifact.deployedBytecode,
    ]);
    const ownerSlotValue = hardhat_1.ethers.zeroPadValue(owner.address, 32);
    const ownerSlot = hardhat_1.ethers.toBeHex(5, 32);
    await hardhat_1.ethers.provider.send('hardhat_setStorageAt', [
        constants_1.AGIALPHA,
        ownerSlot,
        ownerSlotValue,
    ]);
    const token = await hardhat_1.ethers.getContractAt('contracts/test/AGIALPHAToken.sol:AGIALPHAToken', constants_1.AGIALPHA);
    const mint = hardhat_1.ethers.parseUnits('1000', constants_1.AGIALPHA_DECIMALS);
    await token.mint(employer.address, mint);
    await token.mint(agent.address, mint);
    for (const v of validators)
        await token.mint(v.address, mint);
    await token.mint(buyer.address, mint);
    const Stake = await hardhat_1.ethers.getContractFactory('contracts/v2/StakeManager.sol:StakeManager');
    const stake = await Stake.deploy(0, 0, 0, hardhat_1.ethers.ZeroAddress, hardhat_1.ethers.ZeroAddress, hardhat_1.ethers.ZeroAddress, owner.address, await (0, implementations_cjs_1.deployImplementations)('StakeManager', Stake.runner));
    const Reputation = await hardhat_1.ethers.getContractFactory('contracts/v2/ReputationEngine.sol:ReputationEngine');
    const reputation = await Reputation.deploy(await stake.getAddress());
    const ENS = await hardhat_1.ethers.getContractFactory('MockENS');
    const ens = await ENS.deploy();
    const Wrapper = await hardhat_1.ethers.getContractFactory('MockNameWrapper');
    const wrapper = await Wrapper.deploy();
    const Identity = await hardhat_1.ethers.getContractFactory('contracts/v2/IdentityRegistry.sol:IdentityRegistry');
    const identity = await Identity.deploy(await ens.getAddress(), await wrapper.getAddress(), await reputation.getAddress(), hardhat_1.ethers.ZeroHash, hardhat_1.ethers.ZeroHash);
    await identity.setAgentRootNode(hardhat_1.ethers.id('agent-root'));
    await identity.setClubRootNode(hardhat_1.ethers.id('validator-root'));
    const Validation = await hardhat_1.ethers.getContractFactory('contracts/v2/ValidationModule.sol:ValidationModule');
    const validation = await Validation.deploy(hardhat_1.ethers.ZeroAddress, await stake.getAddress(), process.env.DEFAULT_SELECTION ? 0 : 7200, process.env.DEFAULT_SELECTION ? 0 : 7200, 3, process.env.DEFAULT_SELECTION ? 5 : n, [], await (0, implementations_cjs_1.deployImplementations)('ValidationModule', Validation.runner));
    const NFT = await hardhat_1.ethers.getContractFactory('contracts/v2/CertificateNFT.sol:CertificateNFT');
    const nft = await NFT.deploy('Cert', 'CERT');
    const FeePool = await hardhat_1.ethers.getContractFactory('contracts/v2/FeePool.sol:FeePool');
    const feePool = await FeePool.deploy(await stake.getAddress(), 0, hardhat_1.ethers.ZeroAddress, hardhat_1.ethers.ZeroAddress);
    const Registry = await hardhat_1.ethers.getContractFactory('contracts/v2/JobRegistry.sol:JobRegistry');
    const stakeAmt = hardhat_1.ethers.parseUnits('10', constants_1.AGIALPHA_DECIMALS);
    const registry = await Registry.deploy(await validation.getAddress(), await stake.getAddress(), await reputation.getAddress(), hardhat_1.ethers.ZeroAddress, await nft.getAddress(), hardhat_1.ethers.ZeroAddress, hardhat_1.ethers.ZeroAddress, 0, 0, // Legacy fixed stake is disabled; the default is 1000 basis points.
    [], owner.address, await (0, implementations_cjs_1.deployImplementations)('JobRegistry', Registry.runner));
    const Dispute = await hardhat_1.ethers.getContractFactory('contracts/v2/modules/DisputeModule.sol:DisputeModule');
    const dispute = await Dispute.deploy(await registry.getAddress(), 0, 0, hardhat_1.ethers.ZeroAddress, owner.address);
    await dispute.setModerator(moderator.address, 1);
    await dispute.setDisputeWindow(0);
    await dispute.setStakeManager(await stake.getAddress());
    await stake.setModules(await registry.getAddress(), await dispute.getAddress());
    await stake.setValidationModule(await validation.getAddress());
    await validation.setJobRegistry(await registry.getAddress());
    await validation.setStakeManager(await stake.getAddress());
    await validation.setIdentityRegistry(await identity.getAddress());
    await validation.setReputationEngine(await reputation.getAddress());
    if (!process.env.DEFAULT_SELECTION) {
        await validation.setMaxValidatorsPerJob(Math.max(n, 100));
        await validation.setValidatorPoolSampleSize(n);
        await validation.setValidatorsPerJob(n);
        await validation.setRevealQuorum(67, 3);
        await validation.setEarlyFinalizeDelay(0);
    }
    await validation.setValidatorPool(validators.map((v) => v.address));
    await validation.setValidatorSubdomains(validators.map((v) => v.address), validators.map(() => 'validator'));
    for (const v of validators)
        await identity.addAdditionalValidator(v.address);
    await reputation.setCaller(await validation.getAddress(), true);
    await reputation.setThreshold(0);
    await registry.setModules(await validation.getAddress(), await stake.getAddress(), await reputation.getAddress(), await dispute.getAddress(), await nft.getAddress(), await feePool.getAddress(), []);
    await registry.setIdentityRegistry(await identity.getAddress());
    await registry.setValidatorRewardPct(0);
    await stake.setSlashingPercentages(100, 0);
    await nft.setJobRegistry(await registry.getAddress());
    await nft.setStakeManager(await stake.getAddress());
    await reputation.setCaller(await registry.getAddress(), true);
    await reputation.setJobRegistry(await registry.getAddress(), true);
    await reputation.setCaller(owner.address, true);
    await registry.setFeePct(0);
    (0, chai_1.expect)(await registry.jobStakeBps()).to.equal(1000);
    await stake.setBurnPct(0);
    // setCode skips constructors, and escrow/marketplace contracts must accept token terms.
    for (const module of [stake, feePool, nft]) {
        await token.mint(await module.getAddress(), 0);
    }
    return {
        initialAgentBalance: await token.balanceOf(agent.address),
        initialEmployerBalance: await token.balanceOf(employer.address),
        feePool,
        validators,
        owner,
        employer,
        agent,
        validator,
        buyer,
        moderator,
        token,
        stake,
        reputation,
        ens,
        wrapper,
        identity,
        validation,
        nft,
        registry,
        dispute,
        stakeAmt,
    };
}
