import subprocess,time,json,os,signal
from pathlib import Path
out=Path(__file__).parent
with (out/'diagnostic-cancun256-guarded.log').open('w') as f:
 p=subprocess.Popen(['node',str(out/'benchmark.cjs')],stdout=f,stderr=subprocess.STDOUT)
 started=time.monotonic(); peak=0;reason=None
 while p.poll() is None:
  try:
   d=Path(f'/proc/{p.pid}/status').read_text()
   rss=next(int(x.split()[1])*1024 for x in d.splitlines() if x.startswith('VmRSS:'))
   peak=max(peak,rss)
   if rss>1536*1024*1024: reason='RSS exceeded explicit 1536 MiB resource budget';p.terminate()
  except (FileNotFoundError,StopIteration): pass
  if time.monotonic()-started>180:reason='Exceeded explicit 180-second execution budget';p.terminate()
  if reason:
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:p.kill()
   break
  time.sleep(.25)
 code=p.wait()
 resource={'exitCode':code,'peakRssBytes':peak,'elapsedSeconds':time.monotonic()-started,'stopReason':reason,'rssLimitBytes':1536*1024*1024,'timeLimitSeconds':180}
 (out/'diagnostic-cancun256-guarded-resource.json').write_text(json.dumps(resource,indent=2)+'\n')
 print(json.dumps(resource))
