const c = require('/workspace/scratch/1f6e2f637e9a/jobs-resume/reputation-candidate/hardhat.reputation.config.cjs');
// Diagnostic alternate EVM only; no source or artifact writes. No external networks.
c.networks = {hardhat: {...c.networks.hardhat, hardfork:'cancun', blockGasLimit:60000000, gas:60000000}};
module.exports = c;
