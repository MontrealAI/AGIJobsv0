# Public project receipt — frozen before public transport

The permitted software and bounded installed local connected scope is complete.
Fleet and Harness remain held. Read `DELIVERY_RECEIPT.txt` and the JSON receipt
for exact versions, states, supported architectures, refusal boundaries and the
smallest responsible-authority next actions. Four-product execution, live-mobile,
institutional assessment and automatic successor authority are not claimed.
Use `FIRST_RUN.md` for the existing exact-release installation/startup links,
the documented eight-argument Manager command and saved mission9→10→11 files.

Exact connected workspace/receipt/docket/proposal bytes and four substantive
native reports are included unchanged. `PUBLIC_EXPORT_PROJECTION.json` and
`ADDITIONAL_CURRENT_PUBLIC_RECORD_INDEX.json` distinguish exact receipts,
explicitly wrapped local-location projections and new records that postdate the
original raw archive. Projections cannot replace original machine qualification
inputs or canonical scanner results. Failed attempts remain failures.

This data packet is frozen before public transport. Software/native/browser
verification has ended; only finite checkpoint publication/anonymous verification
remains. No unattended campaign continues. Live desktop QA has its exact scoped
receipt: generic Builder1.19.4 recovery is distinct from installed Discovery
docket recovery, raw re-export key ordering differs, one follow-up file was not
delivered and live mobile remains unverified. The data-only archive rebuilder
preserves owner receipt edits; do not rerun the initial preparation helper. `TRANSPORT_PLAN.md` describes the existing data-only
Git evidence process; accepted product refs/assets are not modified by it.

The original raw archive SHA256 is
`80a6bfbcc2d0dd1e23c0d141b71678fa569540c5060313beab0763c8709b94da`.
It and the original TXT are retained unchanged. This is a distinct curated export.
No GitHub/Library write, workflow or native/browser action was performed by this
preparation.
