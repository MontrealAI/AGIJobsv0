# Existing repository data transport plan — not executed

The delivery coordinator owns every publication/ref/comment action below. First
refresh the final source/release/installation/connected/website receipt fields.
Rebuild and review this separate public packet; retain original evidence unchanged.
The local `rebuild_public_archive.py` helper rebuilds only the public inventory and
final ZIP; it preserves owner-edited receipt fields. Do not rerun the initial
preparation helper after filling final outcomes.

## Existing authenticated precedent

Repository: `MontrealAI/AGIJobsv0`.
Existing reachable evidence branch:
`evidence/discovery-rc21-bc4-review-20261024`.
Read-only authenticated head: `40b45d65509c71124520123cc41a3188a751dd29`.
Tree: `800cd155480ffc9300426c89b40f0946a6688954`.
Its sole parent is the published software source `bc4abbd5c28f3672275b13300e40ea26c820b8ee`.
The original consumed publication record remains fixed at commit 40b45d6.
The separate Alpha 17-file transport branch remains reachable at f995b97.

## Preferred Git-data API sequence

1. Use that existing data commit/tree as the parent/base. Add only a new directory
   such as `docs/successor/evidence/delivery-checkpoints/2026-10-24/`; do not change
   product files, historical evidence paths, default branches, tags or release assets.
2. `github_create_blob` supports `encoding: "base64"` for the exact ZIP bytes and
   `encoding: "utf-8"` for the final receipt/integrity/README. Its `content` argument
   is the actual encoded content, not a file path. No large-file upload limit or
   end-to-end binary upload success has been established by this read-only prep.
3. Create a tree with `base_tree_sha` above and only the new closed entries,
   `mode: "100644"`, `type: "blob"`, and returned exact blob SHAs. Create one
   data-only commit with parent 40b45d6; do not create or merge a product PR for data.
4. Give the commit a reachable evidence ref, for example a new
   `evidence/four-repository-delivery-checkpoint-20261024` branch. Check for an
   existing name before creation. If deliberately advancing an existing data
   branch instead, use its freshly observed `expected_sha` and `force: false`.
   A mismatch requires re-reading the ref, not blind retry or a forced update.
5. GET the resulting commit/parent/tree/ref and new blob identities. Download the
   exact ZIP anonymously from the immutable commit URL once; verify its byte
   count, SHA256, ZIP CRC and complete member inventory against the final receipt.
6. Publish the immutable commit/ZIP/checksum/receipt links and exact delivery
   states in the already authorized coordinator issue 4850. Do not include review
   trigger text or imply held-operation or production clearance.

## Standard Git alternative

Git 2.51.1 is present; `gh` is absent. If the coordinator's existing authorized
repository transport already supports ordinary Git pushes, it can use an isolated
data checkout based on 40b45d6, copy only the closed new data directory, create the
normal child commit and push only the new evidence ref. This avoids passing a
binary body through a text-oriented contents tool. Do not discover credentials,
change authentication/settings, run a write-capability probe, or assume a push
permission that has not been established. `github_create_file` is UTF-8-only and
is not a binary ZIP uploader. No release-asset upload tool is exposed here.

An unreferenced commit alone is not the proposed durable endpoint: record the
reachable evidence branch and immutable commit URLs. A transport failure does
not prove an absent write; retain its response, read the exact destination state,
and avoid blind retries or alternate-actor attempts after an action denial.

The final software publisher, installed acceptance and website owner processes
are separate from this project-data transport. Do not republish accepted software
releases merely to store this checkpoint.
